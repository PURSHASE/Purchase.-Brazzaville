// Script pour afficher le graphique avec Chart.js
const ctx = document.getElementById('financeChart');
if (ctx) {
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil'],
      datasets: [
        {
          label: 'Revenus',
          data: [10000, 13000, 17000, 14000, 16000, 21000, 22000],
          borderColor: 'blue',
          fill: false
        },
        {
          label: 'Dépenses',
          data: [5000, 6000, 8000, 7000, 7500, 12000, 11000],
          borderColor: 'black',
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom' } }
    }
  });
}